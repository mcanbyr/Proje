/*********************************************************************************************************************************************************
**
**                                                                SAKARYA �N�VERS�TES�
**                                                      B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**                                                           B�LG�SAYAR M�HEND�SL��� B�L�M�
**                                                          NESNEYE DAYALI PROGRAMLAMA DERS�
**
**
**
**                                            �DEV NUMARASI.........: 1.�dev
**                                            ��RENC� ADI...........: Mehmet Can BAYAR
**                                            ��RENC� NUMARASI......: B231210042
**                                            DERS GRUBU............: 1.��retim / A Grubu
**
**
*************************************************************************************************************************************************************/

using System.Collections.Specialized;
using System.Windows.Forms;

namespace deneme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private bool textChangedByUser = false; //richtextboxtaki de�i�imi kontrol etmek i�in kullan�l�yor

        private void yeniToolStripMenuItem_Click(object sender, EventArgs e)//Yeni dosya a�
        {
            System.Diagnostics.Process.Start(Application.ProductName);
        }

        private void dosyaA�ToolStripMenuItem_Click(object sender, EventArgs e)//Bilgisayardaki dosyay� a�
        {
            openFileDialog1.ShowDialog();
            richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);
        }

        private void dosyaKaydetToolStripMenuItem_Click(object sender, EventArgs e)//Dosyay� kaydet
        {
            KaydetVeKapat();
        }

        private void ��k��ToolStripMenuItem_Click(object sender, EventArgs e)//Programdan ��k�� yap
        {
            DialogResult secim = MessageBox.Show("Program� kapatmadan �nce dosyay� kaydetmek istiyor musunuz?", "��k��", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            if (secim == DialogResult.Yes)
            {
                KaydetVeKapat();// Kullan�c� dosyay� kaydetmek istiyorsa
                Application.Exit();
            }
            else if (secim == DialogResult.No)
            {
                Application.Exit();// Kullan�c� dosyay� kaydetmek istemiyorsa, direkt olarak uygulamay� kapat
            }
        }
        private void KaydetVeKapat()//Dosyay� kaydetme i�lemi burda yap�l�r
        {
            saveFileDialog1.Title = "TXT Olarak Kaydet";
            saveFileDialog1.FileName = Application.ProductName;
            saveFileDialog1.Filter = "Metin Dosyas�(.txt)|.txt";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SaveFile(saveFileDialog1.FileName, RichTextBoxStreamType.PlainText);
            }
            else
            {
                MessageBox.Show("Kaydetme i�lemi iptal edildi.", "�ptal", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void yenileToolStripMenuItem_Click(object sender, EventArgs e)//Dosyay� temizleyerek yeniler
        {
            Application.Restart();
        }

        private void kesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string text_secili = richTextBox1.SelectedText;// TextBox'ta se�ili metni al�r

            if (!string.IsNullOrEmpty(text_secili))// Se�ili metin bo� de�ilse, panoya kopyala ve metni siler
            {
                Clipboard.SetText(text_secili);
                richTextBox1.SelectedText = string.Empty;
            }
        }

        private void kopyalaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selectedText = richTextBox1.SelectedText;

            if (!string.IsNullOrEmpty(selectedText))// Se�ili metin bo� de�ilse, panoya kopyalar
            {
                Clipboard.SetText(selectedText);
            }
        }

        private void yap��t�rToolStripMenuItem_Click(object sender, EventArgs e)
        {

            string yapistirilacak = Clipboard.GetText();// Panodan metni al
            string kopyalanacak = richTextBox1.Text;// TextBox'taki b�t�n metni al
            int imleckonumu = richTextBox1.SelectionStart;// TextBox'taki imlecin konumunu al
            string newText = kopyalanacak.Substring(0, imleckonumu) + yapistirilacak + kopyalanacak.Substring(imleckonumu);// Yap��t�r�lacak metni TextBox'a ekle
            richTextBox1.Text = newText;// TextBox'a yeni metni ata
            richTextBox1.SelectionStart = imleckonumu + yapistirilacak.Length;// �mleci yap��t�r�lan metnin sonuna getir
        }

        private void yaz�Bi�imiToolStripMenuItem_Click(object sender, EventArgs e)
        {

            FontDialog fontDialog = new FontDialog();// Kullan�c�dan bir yaz� tipi se�
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                Font selectedFont = fontDialog.Font;// Se�ilen yaz� tipini al
                string selectedText = richTextBox1.SelectedText;// TextBox'ta se�ili metni al
                Font currentFont = richTextBox1.SelectionFont;// Mevcut yaz� tipini al
                richTextBox1.SelectionFont = selectedFont;// Se�ilen metnin yaz� tipini de�i�tir
            }
        }

        private void yaz�RengiToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ColorDialog colorDialog = new ColorDialog();// Kullan�c�dan bir renk se�
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                Color color_secili = colorDialog.Color;// Se�ilen rengi al
                string text_secili = richTextBox1.SelectedText;// TextBox'ta se�ili metni al
                Color color_mevcut = richTextBox1.SelectionColor;// Mevcut rengi al
                richTextBox1.SelectionColor = color_secili;// Se�ilen metnin rengini de�i�tir
            }
        }

        private void arkaPlanRengiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();// Kullan�c�dan bir renk se�
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                Color selectedColor = colorDialog.Color;// Se�ilen rengi al
                richTextBox1.BackColor = selectedColor;// Richtextbox'�n arka plan rengini de�i�tir
                int selectionStart = richTextBox1.SelectionStart;// T�m metnin arka plan rengini de�i�tir
                int selectionLength = richTextBox1.SelectionLength;
                richTextBox1.SelectAll();
                richTextBox1.SelectionBackColor = selectedColor;
                richTextBox1.Select(selectionStart, selectionLength);// Mevcut se�imi geri y�kle
            }
        }

        private void araToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string searchTerm = aratext.Text;// Aranacak kelimeyi al
            string textToSearch = richTextBox1.Text;// Metin kutusundaki metni al
            int index = 0;// Arama i�lemini ger�ekle�tir
            int searchCount = 0;

            ClearPreviousHighlights();

            while (index != -1)
            {
                index = textToSearch.IndexOf(searchTerm, index, StringComparison.OrdinalIgnoreCase);
                if (index != -1)
                {
                    richTextBox1.Select(index, searchTerm.Length);
                    richTextBox1.SelectionBackColor = Color.Yellow; // Vurgulama rengini ayarlar
                    richTextBox1.ScrollToCaret();
                    searchCount++;
                    index += searchTerm.Length;
                }
            }

            if (searchCount > 0)
            {
                MessageBox.Show($"'{searchTerm}' kelimesi {searchCount} kez bulundu!");
            }
            else
            {
                MessageBox.Show("Kelime bulunamad�!");
            }
            aratext.Clear();
        }
        private void ClearPreviousHighlights() // Arama i�lemi sonras� vurgulu ifadeleri temizlemek i�in
        {
            int selectionStart = richTextBox1.SelectionStart;
            int selectionLength = richTextBox1.SelectionLength;
            richTextBox1.SelectAll();
            richTextBox1.SelectionBackColor = richTextBox1.BackColor;
            richTextBox1.Select(selectionStart, selectionLength);// Mevcut se�im ba�lang�� konumunu geri y�kle
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            lblkrktr.Text = "Krkt :" + richTextBox1.TextLength.ToString();//Metin kutusundaki karakter uzunlu�unu g�ncelle
            sat�rsay�s�.Text = "Str:" + richTextBox1.Lines.Length.ToString();// Metin kutusundaki sat�r say�s�n� g�ncelle
            if (textChangedByUser)// Metin kutusundaki metin de�i�ti�inde �nceki vurgulamalar� kald�r
            {
                ClearPreviousHighlights();
                textChangedByUser = false;
            }
        }

        private void richTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (Console.NumberLock == true)//K�lavyede numlock a��k olup olmad���n� kontrol eder
            {
                lblnumlock.Text = " NumLock A��k ";
                lblnumlock.ForeColor = Color.Blue;
            }
            else
            {
                lblnumlock.Text = " NumLock Kapal� ";
                lblnumlock.ForeColor = Color.Black;
            }

            if (Console.CapsLock == true)//K�lavyede capslock a��k olup olmad���n� kontrol eder
            {
                lblcapslock.Text = " CapsLock A��k ";
                lblcapslock.ForeColor = Color.Blue;
            }
            else
            {
                lblcapslock.Text = " CapsLock Kapal� ";
                lblcapslock.ForeColor = Color.Black;
            }
        }

        private void aratext_KeyDown(object sender, KeyEventArgs e) // Richtextboxta kelime arama i�lemini ger�ekle�tirir
        {
            if (e.KeyCode == Keys.Enter)
            {
                string searchTerm = aratext.Text;// Aranacak kelimeyi al
                string textToSearch = richTextBox1.Text;// Metin kutusundaki metni al
                int index = 0;// Arama i�lemini ger�ekle�tir
                int searchCount = 0;

                ClearPreviousHighlights();

                while (index != -1)
                {
                    index = textToSearch.IndexOf(searchTerm, index, StringComparison.OrdinalIgnoreCase);
                    if (index != -1)
                    {
                        richTextBox1.Select(index, searchTerm.Length); // Kelime bulundu, se�ili yap ve imleci kelimenin ba��na getir
                        richTextBox1.SelectionBackColor = Color.Yellow; // Vurgulama rengi
                        richTextBox1.ScrollToCaret();
                        searchCount++;
                        index += searchTerm.Length;
                    }
                }

                if (searchCount > 0)
                {
                    MessageBox.Show($"'{searchTerm}' kelimesi {searchCount} kez bulundu!");
                }
                else
                {
                    MessageBox.Show("Kelime bulunamad�!");
                }
                aratext.Clear();
            }
        }

        private void richTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            textChangedByUser = true;// Kullan�c� bir tu�a bast���nda, metin de�i�ikli�i kullan�c� taraf�ndan yap�lm�� say�l�r
        }
        // �izim i�lemleri i�in gerekli
        Graphics grafik;
        Pen kalem;
        int konum_x, konum_y;
        Boolean cizimyap;
        int Kalinlik;

        private void �izimA�ToolStripMenuItem_Click(object sender, EventArgs e) //�izim yapabilmek i�in gerekli ayarlar� yapar
        {
            richTextBox1.Visible = false;
            comboBox1.Visible = true;
            label1.Visible = true;
            label1.Location = new Point(comboBox1.Left, comboBox1.Top - label1.Height - 5); // Yaz�y� ComboBox'�n �st�nde konumland�r�r
        }

        private void �izimKapatToolStripMenuItem_Click(object sender, EventArgs e)//�izim k�sm�n� kapatmak i�in gerekli ayarlar� yapar
        {
            richTextBox1.Visible = true;
            comboBox1.Visible = false;
            label1.Visible = false;
            grafik.Clear(BackColor);
        }
        // Fare hareketlerine g�re �izim yapmay� sa�lar
        private void renkToolStripMenuItem_Click(object sender, EventArgs e) // Kalem rengini ayarlama i�lemi
        {
            colorDialog1.ShowDialog();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            cizimyap = true;
            konum_x = e.X;
            konum_y = e.Y;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            kalem = new Pen(colorDialog1.Color, Kalinlik);
            grafik = this.CreateGraphics();
            Point konum1 = new Point(konum_x, konum_y);
            Point konum2 = new Point(e.X, e.Y);
            if (cizimyap == true)
            {
                grafik.DrawLine(kalem, konum1, konum2);
                konum_x = e.X;
                konum_y = e.Y;
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            cizimyap = false;
        }

        private void temizleToolStripMenuItem_Click(object sender, EventArgs e) //Yap�an �izimleri temizler
        {
            grafik.Clear(BackColor);
        }

        private void cToolStripMenuItem_Click(object sender, EventArgs e) // �ablon - C#
        {
            richTextBox1.Clear();
            richTextBox1.AppendText("using System;\r\n\r\nnamespace basitornek\r\n{\r\n    class Program  // s�n�f tan�mlamas�\r\n    {\r\n        static void Main(string[] args)\r\n        {\r\n\r\n             Console.WriteLine(\" Merhaba Millet�);\r\n            Console.ReadKey();\r\n        }\r\n    }\r\n}\r\n");
        }

        private void cToolStripMenuItem1_Click(object sender, EventArgs e)// �ablon - C++
        {
            richTextBox1.Clear();
            richTextBox1.AppendText("#include \nUseing namespace std;  <iostream>\r\n\r\nint main()\r\n{\r\n    std::cout << \"Hello World!\\n\";\r\n}\r\n");
        }

        private void hTMLToolStripMenuItem_Click(object sender, EventArgs e)// �ablon - HTML
        {
            richTextBox1.Clear();
            richTextBox1.AppendText("<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n    <title>Document</title>\r\n</head>\r\n<body>\r\n    \r\n</body>\r\n</html>");
        }

        private void cToolStripMenuItem2_Click(object sender, EventArgs e)// �ablon - C
        {
            richTextBox1.Clear();
            richTextBox1.AppendText("#include<stdio.h>\r\nint main( void )\r\n{\r\n\tprintf(\"Hello World\");\r\n\tprintf(\"\\nMerhaba D�nya\");\r\n\treturn 0;\r\n}");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) // Kalem kal�nl��� ayarlanmas�
        {
            Kalinlik = int.Parse(comboBox1.SelectedItem.ToString());
        }

        private void �izimiKaydetToolStripMenuItem_Click(object sender, EventArgs e) //Yap�lan �izimini g�r�nt�s�n� resim dosyas� olarak kaydet 
        {
            saveFileDialog1.Title = "Resim Olarak Kaydet";
            saveFileDialog1.FileName = Application.ProductName;
            saveFileDialog1.Filter = "Resim Dosyas�(.png)|.png";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Bitmap bitmap = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);

                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    g.CopyFromScreen(this.Location, Point.Empty, this.ClientSize);
                }

                bitmap.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Png);
            }
            else
            {
                MessageBox.Show("Kaydetme i�lemi iptal edildi.", "�ptal", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void kareToolStripMenuItem_Click(object sender, EventArgs e) // Kare �eklini �izer
        {
            System.Drawing.Graphics grafiknesnem;
            grafiknesnem = this.CreateGraphics();
            kalem = new Pen(System.Drawing.Color.Blue, 5);
            Rectangle kare = new Rectangle(200, 100, 200, 200);
            grafiknesnem.DrawRectangle(kalem, kare);

        }

        private void dikd�rtgenToolStripMenuItem_Click(object sender, EventArgs e) // Dikd�rtgen �eklini �izer
        {
            System.Drawing.Graphics grafiknesnem;
            grafiknesnem = this.CreateGraphics();
            kalem = new Pen(System.Drawing.Color.Red, 5);
            Rectangle dortgen = new Rectangle(220, 220, 450, 200);
            grafiknesnem.DrawRectangle(kalem, dortgen);

        }

        private void �emberToolStripMenuItem_Click(object sender, EventArgs e) // �ember �eklini �izer
        {
            System.Drawing.Graphics grafiknesnem;
            grafiknesnem = this.CreateGraphics();
            kalem = new Pen(System.Drawing.Color.Green, 5);
            Rectangle daire = new Rectangle(180, 180, 200, 200);
            grafiknesnem.DrawEllipse(kalem, daire);

        }
    }
}
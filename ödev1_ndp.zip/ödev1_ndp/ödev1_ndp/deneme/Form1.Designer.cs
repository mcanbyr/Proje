﻿namespace deneme
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            statusStrip1 = new StatusStrip();
            lblnumlock = new ToolStripStatusLabel();
            lblcapslock = new ToolStripStatusLabel();
            lblkrktr = new ToolStripStatusLabel();
            satırsayısı = new ToolStripStatusLabel();
            menuStrip1 = new MenuStrip();
            dosyaToolStripMenuItem = new ToolStripMenuItem();
            yeniToolStripMenuItem = new ToolStripMenuItem();
            dosyaAçToolStripMenuItem = new ToolStripMenuItem();
            dosyaKaydetToolStripMenuItem = new ToolStripMenuItem();
            çıkışToolStripMenuItem = new ToolStripMenuItem();
            yenileToolStripMenuItem = new ToolStripMenuItem();
            biçimToolStripMenuItem = new ToolStripMenuItem();
            kesToolStripMenuItem = new ToolStripMenuItem();
            kopyalaToolStripMenuItem = new ToolStripMenuItem();
            yapıştırToolStripMenuItem = new ToolStripMenuItem();
            ayarlarToolStripMenuItem = new ToolStripMenuItem();
            yazıDüzeniToolStripMenuItem = new ToolStripMenuItem();
            yazıBiçimiToolStripMenuItem = new ToolStripMenuItem();
            yazıRengiToolStripMenuItem = new ToolStripMenuItem();
            arkaPlanRengiToolStripMenuItem = new ToolStripMenuItem();
            şaşblonToolStripMenuItem = new ToolStripMenuItem();
            cToolStripMenuItem2 = new ToolStripMenuItem();
            cToolStripMenuItem = new ToolStripMenuItem();
            cToolStripMenuItem1 = new ToolStripMenuItem();
            hTMLToolStripMenuItem = new ToolStripMenuItem();
            çizimToolStripMenuItem = new ToolStripMenuItem();
            çizimAçToolStripMenuItem = new ToolStripMenuItem();
            renkToolStripMenuItem = new ToolStripMenuItem();
            şekillerToolStripMenuItem = new ToolStripMenuItem();
            kareToolStripMenuItem = new ToolStripMenuItem();
            dikdörtgenToolStripMenuItem = new ToolStripMenuItem();
            çemberToolStripMenuItem = new ToolStripMenuItem();
            temizleToolStripMenuItem = new ToolStripMenuItem();
            çizimiKaydetToolStripMenuItem = new ToolStripMenuItem();
            çizimKapatToolStripMenuItem = new ToolStripMenuItem();
            aratext = new ToolStripTextBox();
            araToolStripMenuItem = new ToolStripMenuItem();
            openFileDialog1 = new OpenFileDialog();
            saveFileDialog1 = new SaveFileDialog();
            colorDialog1 = new ColorDialog();
            fontDialog1 = new FontDialog();
            richTextBox1 = new RichTextBox();
            comboBox1 = new ComboBox();
            label1 = new Label();
            statusStrip1.SuspendLayout();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(20, 20);
            statusStrip1.Items.AddRange(new ToolStripItem[] { lblnumlock, lblcapslock, lblkrktr, satırsayısı });
            statusStrip1.Location = new Point(0, 458);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(816, 26);
            statusStrip1.TabIndex = 1;
            statusStrip1.Text = "statusStrip1";
            // 
            // lblnumlock
            // 
            lblnumlock.Name = "lblnumlock";
            lblnumlock.Size = new Size(71, 20);
            lblnumlock.Text = "NumLock";
            // 
            // lblcapslock
            // 
            lblcapslock.Name = "lblcapslock";
            lblcapslock.Size = new Size(71, 20);
            lblcapslock.Text = "CapsLock";
            // 
            // lblkrktr
            // 
            lblkrktr.Name = "lblkrktr";
            lblkrktr.Size = new Size(130, 20);
            lblkrktr.Text = "Karakter Uzunluğu";
            // 
            // satırsayısı
            // 
            satırsayısı.Name = "satırsayısı";
            satırsayısı.Size = new Size(80, 20);
            satırsayısı.Text = "Satır Sayısı";
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { dosyaToolStripMenuItem, biçimToolStripMenuItem, ayarlarToolStripMenuItem, şaşblonToolStripMenuItem, çizimToolStripMenuItem, aratext, araToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(816, 31);
            menuStrip1.TabIndex = 2;
            menuStrip1.Text = "menuStrip1";
            // 
            // dosyaToolStripMenuItem
            // 
            dosyaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { yeniToolStripMenuItem, dosyaAçToolStripMenuItem, dosyaKaydetToolStripMenuItem, çıkışToolStripMenuItem, yenileToolStripMenuItem });
            dosyaToolStripMenuItem.Name = "dosyaToolStripMenuItem";
            dosyaToolStripMenuItem.Size = new Size(64, 27);
            dosyaToolStripMenuItem.Text = "Dosya";
            // 
            // yeniToolStripMenuItem
            // 
            yeniToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_file_641;
            yeniToolStripMenuItem.Name = "yeniToolStripMenuItem";
            yeniToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.N;
            yeniToolStripMenuItem.Size = new Size(233, 26);
            yeniToolStripMenuItem.Text = "Yeni";
            yeniToolStripMenuItem.Click += yeniToolStripMenuItem_Click;
            // 
            // dosyaAçToolStripMenuItem
            // 
            dosyaAçToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_opened_folder_641;
            dosyaAçToolStripMenuItem.Name = "dosyaAçToolStripMenuItem";
            dosyaAçToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.O;
            dosyaAçToolStripMenuItem.Size = new Size(233, 26);
            dosyaAçToolStripMenuItem.Text = "Dosya Aç";
            dosyaAçToolStripMenuItem.Click += dosyaAçToolStripMenuItem_Click;
            // 
            // dosyaKaydetToolStripMenuItem
            // 
            dosyaKaydetToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_downloads_folder_501;
            dosyaKaydetToolStripMenuItem.Name = "dosyaKaydetToolStripMenuItem";
            dosyaKaydetToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.S;
            dosyaKaydetToolStripMenuItem.Size = new Size(233, 26);
            dosyaKaydetToolStripMenuItem.Text = "Dosya Kaydet";
            dosyaKaydetToolStripMenuItem.Click += dosyaKaydetToolStripMenuItem_Click;
            // 
            // çıkışToolStripMenuItem
            // 
            çıkışToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_cancel_641;
            çıkışToolStripMenuItem.Name = "çıkışToolStripMenuItem";
            çıkışToolStripMenuItem.ShortcutKeys = Keys.Alt | Keys.F4;
            çıkışToolStripMenuItem.Size = new Size(233, 26);
            çıkışToolStripMenuItem.Text = "Çıkış";
            çıkışToolStripMenuItem.Click += çıkışToolStripMenuItem_Click;
            // 
            // yenileToolStripMenuItem
            // 
            yenileToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_refresh_641;
            yenileToolStripMenuItem.Name = "yenileToolStripMenuItem";
            yenileToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.R;
            yenileToolStripMenuItem.Size = new Size(233, 26);
            yenileToolStripMenuItem.Text = "Yenile";
            yenileToolStripMenuItem.Click += yenileToolStripMenuItem_Click;
            // 
            // biçimToolStripMenuItem
            // 
            biçimToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { kesToolStripMenuItem, kopyalaToolStripMenuItem, yapıştırToolStripMenuItem });
            biçimToolStripMenuItem.Name = "biçimToolStripMenuItem";
            biçimToolStripMenuItem.Size = new Size(60, 27);
            biçimToolStripMenuItem.Text = "Biçim";
            // 
            // kesToolStripMenuItem
            // 
            kesToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_cut_501;
            kesToolStripMenuItem.Name = "kesToolStripMenuItem";
            kesToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.X;
            kesToolStripMenuItem.Size = new Size(197, 26);
            kesToolStripMenuItem.Text = "Kes";
            kesToolStripMenuItem.Click += kesToolStripMenuItem_Click;
            // 
            // kopyalaToolStripMenuItem
            // 
            kopyalaToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_copy_501;
            kopyalaToolStripMenuItem.Name = "kopyalaToolStripMenuItem";
            kopyalaToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.C;
            kopyalaToolStripMenuItem.Size = new Size(197, 26);
            kopyalaToolStripMenuItem.Text = "Kopyala";
            kopyalaToolStripMenuItem.Click += kopyalaToolStripMenuItem_Click;
            // 
            // yapıştırToolStripMenuItem
            // 
            yapıştırToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_paste_641;
            yapıştırToolStripMenuItem.Name = "yapıştırToolStripMenuItem";
            yapıştırToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.V;
            yapıştırToolStripMenuItem.Size = new Size(197, 26);
            yapıştırToolStripMenuItem.Text = "Yapıştır";
            yapıştırToolStripMenuItem.Click += yapıştırToolStripMenuItem_Click;
            // 
            // ayarlarToolStripMenuItem
            // 
            ayarlarToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { yazıDüzeniToolStripMenuItem, arkaPlanRengiToolStripMenuItem });
            ayarlarToolStripMenuItem.Name = "ayarlarToolStripMenuItem";
            ayarlarToolStripMenuItem.Size = new Size(70, 27);
            ayarlarToolStripMenuItem.Text = "Ayarlar";
            // 
            // yazıDüzeniToolStripMenuItem
            // 
            yazıDüzeniToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { yazıBiçimiToolStripMenuItem, yazıRengiToolStripMenuItem });
            yazıDüzeniToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_abc_641;
            yazıDüzeniToolStripMenuItem.Name = "yazıDüzeniToolStripMenuItem";
            yazıDüzeniToolStripMenuItem.Size = new Size(196, 26);
            yazıDüzeniToolStripMenuItem.Text = "Yazı Düzeni";
            // 
            // yazıBiçimiToolStripMenuItem
            // 
            yazıBiçimiToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_font_size_501;
            yazıBiçimiToolStripMenuItem.Name = "yazıBiçimiToolStripMenuItem";
            yazıBiçimiToolStripMenuItem.Size = new Size(163, 26);
            yazıBiçimiToolStripMenuItem.Text = "Yazı Biçimi";
            yazıBiçimiToolStripMenuItem.Click += yazıBiçimiToolStripMenuItem_Click;
            // 
            // yazıRengiToolStripMenuItem
            // 
            yazıRengiToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_text_color_50__1_2;
            yazıRengiToolStripMenuItem.Name = "yazıRengiToolStripMenuItem";
            yazıRengiToolStripMenuItem.Size = new Size(163, 26);
            yazıRengiToolStripMenuItem.Text = "Yazı Rengi";
            yazıRengiToolStripMenuItem.Click += yazıRengiToolStripMenuItem_Click;
            // 
            // arkaPlanRengiToolStripMenuItem
            // 
            arkaPlanRengiToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_background_641;
            arkaPlanRengiToolStripMenuItem.Name = "arkaPlanRengiToolStripMenuItem";
            arkaPlanRengiToolStripMenuItem.Size = new Size(196, 26);
            arkaPlanRengiToolStripMenuItem.Text = "Arka Plan Rengi";
            arkaPlanRengiToolStripMenuItem.Click += arkaPlanRengiToolStripMenuItem_Click;
            // 
            // şaşblonToolStripMenuItem
            // 
            şaşblonToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cToolStripMenuItem2, cToolStripMenuItem, cToolStripMenuItem1, hTMLToolStripMenuItem });
            şaşblonToolStripMenuItem.Name = "şaşblonToolStripMenuItem";
            şaşblonToolStripMenuItem.Size = new Size(69, 27);
            şaşblonToolStripMenuItem.Text = "Şablon";
            // 
            // cToolStripMenuItem2
            // 
            cToolStripMenuItem2.Image = ödev1_ndp.Properties.Resources.letter_c1;
            cToolStripMenuItem2.Name = "cToolStripMenuItem2";
            cToolStripMenuItem2.Size = new Size(131, 26);
            cToolStripMenuItem2.Text = "C";
            cToolStripMenuItem2.Click += cToolStripMenuItem2_Click;
            // 
            // cToolStripMenuItem
            // 
            cToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.c_sharp1;
            cToolStripMenuItem.Name = "cToolStripMenuItem";
            cToolStripMenuItem.Size = new Size(131, 26);
            cToolStripMenuItem.Text = "C#";
            cToolStripMenuItem.Click += cToolStripMenuItem_Click;
            // 
            // cToolStripMenuItem1
            // 
            cToolStripMenuItem1.Image = ödev1_ndp.Properties.Resources.c___1_1;
            cToolStripMenuItem1.Name = "cToolStripMenuItem1";
            cToolStripMenuItem1.Size = new Size(131, 26);
            cToolStripMenuItem1.Text = "C++";
            cToolStripMenuItem1.Click += cToolStripMenuItem1_Click;
            // 
            // hTMLToolStripMenuItem
            // 
            hTMLToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.html1;
            hTMLToolStripMenuItem.Name = "hTMLToolStripMenuItem";
            hTMLToolStripMenuItem.Size = new Size(131, 26);
            hTMLToolStripMenuItem.Text = "HTML";
            hTMLToolStripMenuItem.Click += hTMLToolStripMenuItem_Click;
            // 
            // çizimToolStripMenuItem
            // 
            çizimToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { çizimAçToolStripMenuItem, renkToolStripMenuItem, şekillerToolStripMenuItem, temizleToolStripMenuItem, çizimiKaydetToolStripMenuItem, çizimKapatToolStripMenuItem });
            çizimToolStripMenuItem.Name = "çizimToolStripMenuItem";
            çizimToolStripMenuItem.Size = new Size(60, 27);
            çizimToolStripMenuItem.Text = "Çizim";
            // 
            // çizimAçToolStripMenuItem
            // 
            çizimAçToolStripMenuItem.Name = "çizimAçToolStripMenuItem";
            çizimAçToolStripMenuItem.Size = new Size(224, 26);
            çizimAçToolStripMenuItem.Text = "Kalem";
            çizimAçToolStripMenuItem.Click += çizimAçToolStripMenuItem_Click;
            // 
            // renkToolStripMenuItem
            // 
            renkToolStripMenuItem.Name = "renkToolStripMenuItem";
            renkToolStripMenuItem.Size = new Size(224, 26);
            renkToolStripMenuItem.Text = "Renk";
            renkToolStripMenuItem.Click += renkToolStripMenuItem_Click;
            // 
            // şekillerToolStripMenuItem
            // 
            şekillerToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { kareToolStripMenuItem, dikdörtgenToolStripMenuItem, çemberToolStripMenuItem });
            şekillerToolStripMenuItem.Name = "şekillerToolStripMenuItem";
            şekillerToolStripMenuItem.Size = new Size(224, 26);
            şekillerToolStripMenuItem.Text = "Şekiller";
            // 
            // kareToolStripMenuItem
            // 
            kareToolStripMenuItem.Name = "kareToolStripMenuItem";
            kareToolStripMenuItem.Size = new Size(224, 26);
            kareToolStripMenuItem.Text = "Kare";
            kareToolStripMenuItem.Click += kareToolStripMenuItem_Click;
            // 
            // dikdörtgenToolStripMenuItem
            // 
            dikdörtgenToolStripMenuItem.Name = "dikdörtgenToolStripMenuItem";
            dikdörtgenToolStripMenuItem.Size = new Size(224, 26);
            dikdörtgenToolStripMenuItem.Text = "Dikdörtgen";
            dikdörtgenToolStripMenuItem.Click += dikdörtgenToolStripMenuItem_Click;
            // 
            // çemberToolStripMenuItem
            // 
            çemberToolStripMenuItem.Name = "çemberToolStripMenuItem";
            çemberToolStripMenuItem.Size = new Size(224, 26);
            çemberToolStripMenuItem.Text = "Çember";
            çemberToolStripMenuItem.Click += çemberToolStripMenuItem_Click;
            // 
            // temizleToolStripMenuItem
            // 
            temizleToolStripMenuItem.Name = "temizleToolStripMenuItem";
            temizleToolStripMenuItem.Size = new Size(224, 26);
            temizleToolStripMenuItem.Text = "Temizle";
            temizleToolStripMenuItem.Click += temizleToolStripMenuItem_Click;
            // 
            // çizimiKaydetToolStripMenuItem
            // 
            çizimiKaydetToolStripMenuItem.Name = "çizimiKaydetToolStripMenuItem";
            çizimiKaydetToolStripMenuItem.Size = new Size(224, 26);
            çizimiKaydetToolStripMenuItem.Text = "Kaydet";
            çizimiKaydetToolStripMenuItem.Click += çizimiKaydetToolStripMenuItem_Click;
            // 
            // çizimKapatToolStripMenuItem
            // 
            çizimKapatToolStripMenuItem.Name = "çizimKapatToolStripMenuItem";
            çizimKapatToolStripMenuItem.Size = new Size(224, 26);
            çizimKapatToolStripMenuItem.Text = "Kaydetmeden Çık ";
            çizimKapatToolStripMenuItem.Click += çizimKapatToolStripMenuItem_Click;
            // 
            // aratext
            // 
            aratext.BorderStyle = BorderStyle.FixedSingle;
            aratext.Name = "aratext";
            aratext.Size = new Size(150, 27);
            aratext.KeyDown += aratext_KeyDown;
            // 
            // araToolStripMenuItem
            // 
            araToolStripMenuItem.Image = ödev1_ndp.Properties.Resources.icons8_search_501;
            araToolStripMenuItem.Name = "araToolStripMenuItem";
            araToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.F;
            araToolStripMenuItem.Size = new Size(66, 27);
            araToolStripMenuItem.Text = "Ara";
            araToolStripMenuItem.Click += araToolStripMenuItem_Click;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // richTextBox1
            // 
            richTextBox1.Dock = DockStyle.Fill;
            richTextBox1.Location = new Point(0, 31);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(816, 427);
            richTextBox1.TabIndex = 3;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            richTextBox1.KeyDown += richTextBox1_KeyDown;
            richTextBox1.KeyPress += richTextBox1_KeyPress;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50" });
            comboBox1.Location = new Point(655, 34);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(161, 28);
            comboBox1.TabIndex = 4;
            comboBox1.Visible = false;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.WindowText;
            label1.Location = new Point(675, 65);
            label1.Name = "label1";
            label1.Size = new Size(129, 19);
            label1.TabIndex = 5;
            label1.Text = "Kalem Kalınlığı";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            label1.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(816, 484);
            Controls.Add(label1);
            Controls.Add(comboBox1);
            Controls.Add(richTextBox1);
            Controls.Add(statusStrip1);
            Controls.Add(menuStrip1);
            Name = "Form1";
            Text = "Form1";
            MouseDown += Form1_MouseDown;
            MouseMove += Form1_MouseMove;
            MouseUp += Form1_MouseUp;
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private StatusStrip statusStrip1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem dosyaToolStripMenuItem;
        private ToolStripMenuItem biçimToolStripMenuItem;
        private ToolStripStatusLabel lblnumlock;
        private ToolStripMenuItem ayarlarToolStripMenuItem;
        private ToolStripTextBox aratext;
        private ToolStripStatusLabel lblcapslock;
        private ToolStripStatusLabel lblkrktr;
        private ToolStripStatusLabel satırsayısı;
        private ToolStripMenuItem yeniToolStripMenuItem;
        private ToolStripMenuItem dosyaAçToolStripMenuItem;
        private ToolStripMenuItem dosyaKaydetToolStripMenuItem;
        private ToolStripMenuItem çıkışToolStripMenuItem;
        private ToolStripMenuItem yenileToolStripMenuItem;
        private ToolStripMenuItem kesToolStripMenuItem;
        private ToolStripMenuItem kopyalaToolStripMenuItem;
        private ToolStripMenuItem yapıştırToolStripMenuItem;
        private ToolStripMenuItem yazıDüzeniToolStripMenuItem;
        private ToolStripMenuItem yazıBiçimiToolStripMenuItem;
        private ToolStripMenuItem yazıRengiToolStripMenuItem;
        private ToolStripMenuItem arkaPlanRengiToolStripMenuItem;
        private OpenFileDialog openFileDialog1;
        private SaveFileDialog saveFileDialog1;
        private ColorDialog colorDialog1;
        private FontDialog fontDialog1;
        private ToolStripMenuItem araToolStripMenuItem;
        private RichTextBox richTextBox1;
        private ToolStripMenuItem çizimToolStripMenuItem;
        private ToolStripMenuItem çizimAçToolStripMenuItem;
        private ToolStripMenuItem çizimKapatToolStripMenuItem;
        private ToolStripMenuItem renkToolStripMenuItem;
        private ToolStripMenuItem temizleToolStripMenuItem;
        private ToolStripMenuItem şaşblonToolStripMenuItem;
        private ToolStripMenuItem cToolStripMenuItem;
        private ToolStripMenuItem cToolStripMenuItem1;
        private ToolStripMenuItem hTMLToolStripMenuItem;
        private ToolStripMenuItem cToolStripMenuItem2;
        private ComboBox comboBox1;
        private Label label1;
        private ToolStripMenuItem çizimiKaydetToolStripMenuItem;
        private ToolStripMenuItem şekillerToolStripMenuItem;
        private ToolStripMenuItem kareToolStripMenuItem;
        private ToolStripMenuItem dikdörtgenToolStripMenuItem;
        private ToolStripMenuItem çemberToolStripMenuItem;
    }
}